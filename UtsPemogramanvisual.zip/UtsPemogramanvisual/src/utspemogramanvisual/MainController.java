package utspemogramanvisual;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

public class MainController {

    @FXML
    private TableView<Buku> tableBuku;
    @FXML
    private TableColumn<Buku, String> columnKode;
    @FXML
    private TableColumn<Buku, String> columnJudul;
    @FXML
    private TableColumn<Buku, String> columnPengarang;
    @FXML
    private TableColumn<Buku, String> columnPenerbit;
    @FXML
    private TableColumn<Buku, String> columnTahun;
    @FXML
    private TableColumn<Buku, String> columnEdisi;

    @FXML
    private TextField txtKode;
    @FXML
    private TextField txtJudul;
    @FXML
    private TextField txtPengarang;
    @FXML
    private TextField txtPenerbit;
    @FXML
    private TextField txtTahun;
    @FXML
    private TextField txtEdisi;

    private ObservableList<Buku> daftarBuku = FXCollections.observableArrayList();
    private Buku selectedBuku;
    private String kodeBukuLama;

    @FXML
    public void initialize() {
        columnKode.setCellValueFactory(data -> data.getValue().kodeProperty());
        columnJudul.setCellValueFactory(data -> data.getValue().judulProperty());
        columnPengarang.setCellValueFactory(data -> data.getValue().pengarangProperty());
        columnPenerbit.setCellValueFactory(data -> data.getValue().penerbitProperty());
        columnTahun.setCellValueFactory(data -> data.getValue().tahunProperty());
        columnEdisi.setCellValueFactory(data -> data.getValue().edisiProperty());

        daftarBuku.setAll(BukuDAO.getAllBuku());
        tableBuku.setItems(daftarBuku);

        tableBuku.setOnMouseClicked(event -> {
            selectedBuku = tableBuku.getSelectionModel().getSelectedItem();
            if (selectedBuku != null) {
                txtKode.setText(selectedBuku.getKode());
                txtJudul.setText(selectedBuku.getJudul());
                txtPengarang.setText(selectedBuku.getPengarang());
                txtPenerbit.setText(selectedBuku.getPenerbit());
                txtTahun.setText(selectedBuku.getTahun());
                txtEdisi.setText(selectedBuku.getEdisi());
                kodeBukuLama = selectedBuku.getKode();
                txtKode.setDisable(true); // ⛔ Disable agar tidak bisa diubah
            }
        });
    }

    @FXML
    private void handleAdd() {
        String kode = txtKode.getText();
        String judul = txtJudul.getText();
        String pengarang = txtPengarang.getText();
        String penerbit = txtPenerbit.getText();
        String tahun = txtTahun.getText();
        String edisi = txtEdisi.getText();

        if (kode.isEmpty() || judul.isEmpty() || pengarang.isEmpty() || penerbit.isEmpty() || tahun.isEmpty() || edisi.isEmpty()) {
            showAlert("Input Error", "Semua field harus diisi!");
            return;
        }

        if (!kode.matches("\\d+") || !tahun.matches("\\d{4}") || !edisi.matches("\\d+")) {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Warning");
            warning.setHeaderText("Input tidak valid");
            warning.setContentText("Silakan periksa kembali input Anda. Kode buku, tahun dan edisi harus diisi dengan angka.");
            warning.showAndWait();
            return;
        }

        Alert confirm = new Alert(AlertType.CONFIRMATION);
        confirm.setTitle("Konfirmasi ?");
        confirm.setHeaderText("Tambah Data ?");
        confirm.setContentText("Data akan disimpan jika pilih OK");

        ButtonType result = confirm.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            if (BukuDAO.exists(kode)) {
                showAlert("Input Error", "Kode buku sudah ada. Gunakan kode lain.");
                return;
            }

            Buku bukuBaru = new Buku(kode, judul, pengarang, penerbit, tahun, edisi);
            BukuDAO.tambahBuku(bukuBaru);
            daftarBuku.setAll(BukuDAO.getAllBuku());
            clearFields();

            Alert info = new Alert(AlertType.INFORMATION);
            info.setTitle("Informasi");
            info.setHeaderText("Tambah Berhasil!");
            info.setContentText("Data buku berhasil ditambahkan.");
            info.showAndWait();
        }
    }

    @FXML
    private void handleUpdate() {
        if (selectedBuku == null || kodeBukuLama == null) {
            showAlert("Selection Error", "Pilih data buku terlebih dahulu di tabel.");
            return;
        }

        String judul = txtJudul.getText();
        String pengarang = txtPengarang.getText();
        String penerbit = txtPenerbit.getText();
        String tahun = txtTahun.getText();
        String edisi = txtEdisi.getText();

        if (judul.isEmpty() || pengarang.isEmpty() || penerbit.isEmpty() || tahun.isEmpty() || edisi.isEmpty()) {
            showAlert("Input Error", "Semua field harus diisi untuk update!");
            return;
        }

        if (!tahun.matches("\\d{4}") || !edisi.matches("\\d+")) {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            warning.setTitle("Warning");
            warning.setHeaderText("Input tidak valid");
            warning.setContentText("Silakan periksa kembali input Anda. Tahun dan edisi harus diisi dengan angka.");
            warning.showAndWait();
            return;
        }

        Alert confirm = new Alert(AlertType.CONFIRMATION);
        confirm.setTitle("Konfirmasi ?");
        confirm.setHeaderText("Perbarui Data ?");
        confirm.setContentText("Data akan diperbarui jika pilih OK");

        ButtonType result = confirm.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            Buku bukuBaru = new Buku(kodeBukuLama, judul, pengarang, penerbit, tahun, edisi);
            BukuDAO.updateBuku(bukuBaru);

            daftarBuku.setAll(BukuDAO.getAllBuku());
            clearFields();

            Alert info = new Alert(AlertType.INFORMATION);
            info.setTitle("Informasi");
            info.setHeaderText("Update Berhasil!");
            info.setContentText("Data buku berhasil diperbarui.");
            info.showAndWait();
        }
    }

    @FXML
    private void handleDelete() {
        if (selectedBuku == null) {
            showAlert("Selection Error", "Pilih data buku terlebih dahulu.");
            return;
        }

        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Konfirmasi ?");
        alert.setHeaderText("Hapus Data ?");
        alert.setContentText("Data akan terhapus jika pilih OK");

        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            BukuDAO.hapusBuku(selectedBuku.getKode());
            daftarBuku.setAll(BukuDAO.getAllBuku());
            clearFields();

            Alert info = new Alert(AlertType.INFORMATION);
            info.setTitle("Informasi");
            info.setHeaderText("Proses hapus berhasil!");
            info.setContentText("Data buku terhapus.");
            info.showAndWait();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        txtKode.clear();
        txtJudul.clear();
        txtPengarang.clear();
        txtPenerbit.clear();
        txtTahun.clear();
        txtEdisi.clear();
        txtKode.setDisable(false);
        selectedBuku = null;
        kodeBukuLama = null;
    }
}
