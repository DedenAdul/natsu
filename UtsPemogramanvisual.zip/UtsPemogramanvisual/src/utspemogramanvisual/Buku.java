package utspemogramanvisual;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Buku {

    private final StringProperty kode;
    private final StringProperty judul;
    private final StringProperty pengarang;
    private final StringProperty penerbit;
    private final StringProperty tahun;
    private final StringProperty edisi;

    public Buku(String kode, String judul, String pengarang, String penerbit, String tahun, String edisi) {
        this.kode = new SimpleStringProperty(kode);
        this.judul = new SimpleStringProperty(judul);
        this.pengarang = new SimpleStringProperty(pengarang);
        this.penerbit = new SimpleStringProperty(penerbit);
        this.tahun = new SimpleStringProperty(tahun);
        this.edisi = new SimpleStringProperty(edisi);
    }

    // Getter & Setter nilai
    public String getKode() { return kode.get(); }
    public void setKode(String kode) { this.kode.set(kode); }

    public String getJudul() { return judul.get(); }
    public void setJudul(String judul) { this.judul.set(judul); }

    public String getPengarang() { return pengarang.get(); }
    public void setPengarang(String pengarang) { this.pengarang.set(pengarang); }

    public String getPenerbit() { return penerbit.get(); }
    public void setPenerbit(String penerbit) { this.penerbit.set(penerbit); }

    public String getTahun() { return tahun.get(); }
    public void setTahun(String tahun) { this.tahun.set(tahun); }

    public String getEdisi() { return edisi.get(); }
    public void setEdisi(String edisi) { this.edisi.set(edisi); }

    // Property untuk binding di TableView
    public StringProperty kodeProperty() { return kode; }
    public StringProperty judulProperty() { return judul; }
    public StringProperty pengarangProperty() { return pengarang; }
    public StringProperty penerbitProperty() { return penerbit; }
    public StringProperty tahunProperty() { return tahun; }
    public StringProperty edisiProperty() { return edisi; }
}
