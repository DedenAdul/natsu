package utspemogramanvisual;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BukuDAO {

    public static void tambahBuku(Buku buku) {
        String sql = "INSERT INTO buku (kode_buku, judul, pengarang, penerbit, tahun_terbit, edisi) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, buku.getKode());
            ps.setString(2, buku.getJudul());
            ps.setString(3, buku.getPengarang());
            ps.setString(4, buku.getPenerbit());
            ps.setString(5, buku.getTahun());
            ps.setString(6, buku.getEdisi());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Gagal menambahkan buku: " + e.getMessage());
        }
    }

    public static void updateBuku(Buku buku) {
        String sql = "UPDATE buku SET judul=?, pengarang=?, penerbit=?, tahun_terbit=?, edisi=? WHERE kode_buku=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, buku.getJudul());
            ps.setString(2, buku.getPengarang());
            ps.setString(3, buku.getPenerbit());
            ps.setString(4, buku.getTahun());
            ps.setString(5, buku.getEdisi());
            ps.setString(6, buku.getKode());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Gagal mengupdate buku: " + e.getMessage());
        }
    }

    public static void hapusBuku(String kode) {
        String sql = "DELETE FROM buku WHERE kode_buku=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, kode);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Gagal menghapus buku: " + e.getMessage());
        }
    }

    public static List<Buku> getAllBuku() {
        List<Buku> list = new ArrayList<>();
        String sql = "SELECT * FROM buku";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Buku b = new Buku(
                    rs.getString("kode_buku"),
                    rs.getString("judul"),
                    rs.getString("pengarang"),
                    rs.getString("penerbit"),
                    rs.getString("tahun_terbit"),
                    rs.getString("edisi")
                );
                list.add(b);
            }
        } catch (SQLException e) {
            System.err.println("Gagal mengambil data buku: " + e.getMessage());
        }

        return list;
    }

    // ✅ Tambahan: Cek apakah kode buku sudah ada
    public static boolean exists(String kodeBuku) {
        String sql = "SELECT COUNT(*) FROM buku WHERE kode_buku=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, kodeBuku);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Gagal memeriksa keberadaan buku: " + e.getMessage());
        }
        return false;
    }
}
